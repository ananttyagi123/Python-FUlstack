console.log("Login page loaded");
var hello = "first variable .";



function data(){
    var greet = "hello Anant"
    console.log(greet)
}

data();


// cannot redeclare , but reassign the variable 

 
let a = 56
let b = 45
let hello = (a,b) =>{
     return  a*b
 }

console.log(hello(a,b))






