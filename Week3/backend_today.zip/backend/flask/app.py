from flask import Flask, render_template, redirect, url_for

app = Flask(__name__)


@app.route('/')
def Index():
    return render_template('index.html')

@app.route('/home')
def Home():
    return render_template('home.html')

@app.route('/newpage')
def NewPage():
    return render_template('newpage.html')

@app.route('/dashboard/<name>')
def Dashboard(name):
    if name == 'admin':
        return redirect(url_for('Home'))
    elif name == 'user':
        return redirect(url_for('NewPage'))
    elif name == 'index':
        return redirect(url_for('Index'))
    else:
        return "Invalid user type", 404
    
@app.route('/if')
def If_example():
    message = 'hello'
    return render_template('if.html', message=message)

@app.route('/for')
def for_example():
    courses = ['Python', 'Java', 'C++']
    return render_template('for_example.html', courses=courses)

if __name__ == '__main__':
    app.run(debug=True)
